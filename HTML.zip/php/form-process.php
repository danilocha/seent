<?php

$errorMSG = "";

// NAME
if (empty($_POST["name"])) {
    $errorMSG = "El nombre es obligario ";
} else {
    $name = $_POST["name"];
}

// EMAIL
if (empty($_POST["email"])) {
    $errorMSG .= "El email es obligatorio ";
} else {
    $email = $_POST["email"];
}

// SUBJECT
if (empty($_POST["subject"])) {
    $errorMSG .= "El asunto es obligatorio";
} else {
    $subject = $_POST["subject"];
}
// phone
if (empty($_POST["phone"])) {
    $errorMSG .= "El Telefono es obligatorio";
} else {
    $phone = $_POST["phone"];
}

// MESSAGE
if (empty($_POST["message"])) {
    $errorMSG .= "El mensaje es obligatorio ";
} else {
    $message = $_POST["message"];
}


$EmailTo = "seent.tramites@gmail.com";
$Subject = $subject;

// prepare email body text
$Body = "";
$Body .= "Nombre: ";
$Body .= $name;
$Body .= "\n";
$Body .= "Email: ";
$Body .= $email;
$Body .= "\n";
$Body .= "Telefono: ";
$Body .= $phone;
$Body .= "\n";
$Body .= "Mensaje: ";
$Body .= $message;
$Body .= "\n";

// send email
$success = mail($EmailTo, $Subject, $Body, "From:".$email);

// redirect to success page
if ($success && $errorMSG == ""){
   echo "Tu mensaje a sido enviado";
}else{
    if($errorMSG == ""){
        echo "Algo fallo :/ pero puedes llamarnos al: 313 3126271 :D";
    } else {
        echo $errorMSG;
    }
}

?>